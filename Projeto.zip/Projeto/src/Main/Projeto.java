/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package Main;

import Controllers.PokeDaoController;
import Models.Poke.Poke;
import Models.PokeDAO;
import Views.ControllerMenu;
import java.util.Optional;
/**
 *
 * @author Aluno
 */
public class Projeto{
   // --module-path "C:\Users\Aluno\Documents\Java libries\javafx-sdk-23.0.1\lib" --add-modules javafx.controls,javafx.fxml
    /*
    private static Scene scene;

    /**
     * @param args the command line arguments
     */

}