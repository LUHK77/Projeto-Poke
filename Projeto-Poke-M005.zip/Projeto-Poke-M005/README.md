# Projeto Poke
> Status do projeto: em desenvolvimento:

# Sobre o Projeto

 Este projeto foi criado e desenvolvido no senac de 11/2024 a 01/2025
Conta com uma tela de seleção de personagem onde disponibiliza 4 personagens utilizaveis para o jogo.
Este jogo conta com o sitema de elementos onde cada pode cauterar um especifico. 
Agua ganha de fogo
